from flask import Blueprint, render_template, session, request, flash, redirect, url_for, Response
from authentication import login_required
from db import connect_to_db

cliente_routes = Blueprint('cliente', __name__)

def add_no_cache_headers(response):
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    return response

@cliente_routes.route('/cliente')
@login_required
def cliente():
    user_id = session.get('user_id')  # Usar get() para evitar KeyError si 'user_id' no está en la sesión
    if user_id is None:
        return redirect(url_for('login.login'))

    conn = connect_to_db()
    if conn:
        cursor = conn.cursor()
        # Consulta los horarios disponibles para agendar
        sql = "SELECT h.id_horario, s.nombre, h.fecha, h.hora, h.disponibilidad FROM Horarios h JOIN Servicios s ON h.id_servicio = s.id_servicio WHERE h.disponibilidad = 1"
        cursor.execute(sql)
        horarios_disponibles = cursor.fetchall()
        cursor.close()
        conn.close()
        template = render_template('cliente.html', horarios_disponibles=horarios_disponibles)
        response = Response(template)
        return add_no_cache_headers(response)
    else:
        return "Error de conexión a la base de datos"

@cliente_routes.route('/agendar_cita', methods=['POST'])
@login_required
def agendar_cita():
    user_id = session.get('user_id')  # Usar get() para evitar KeyError si 'user_id' no está en la sesión
    horario_id = request.form.get('horario_id')  # Obtiene el ID del horario seleccionado

    conn = connect_to_db()
    if conn:
        cursor = conn.cursor()
        try:
            # Verifica si el horario seleccionado todavía está disponible
            sql_check_disponibilidad = "SELECT disponibilidad FROM Horarios WHERE id_horario = %s"
            cursor.execute(sql_check_disponibilidad, (horario_id,))
            disponibilidad = cursor.fetchone()[0]

            if disponibilidad == 1:  # El horario todavía está disponible
                # Actualiza la disponibilidad del horario a no disponible (0)
                sql_update_disponibilidad = "UPDATE Horarios SET disponibilidad = 0 WHERE id_horario = %s"
                cursor.execute(sql_update_disponibilidad, (horario_id,))
                conn.commit()

                # Inserta la cita en la tabla de citas (debes implementar esto según tu estructura de datos)
                sql_insert_cita = "INSERT INTO Citas (id_usuario, id_horario) VALUES (%s, %s)"
                cursor.execute(sql_insert_cita, (user_id, horario_id))
                conn.commit()

                flash("Cita agendada exitosamente", "success")
            else:
                flash("El horario seleccionado ya no está disponible", "warning")
        except Exception as e:
            flash(f"Error al agendar la cita: {str(e)}", "error")
        finally:
            cursor.close()
            conn.close()
    else:
        flash("Error de conexión a la base de datos", "error")

    return redirect(url_for('cliente.cliente'))

